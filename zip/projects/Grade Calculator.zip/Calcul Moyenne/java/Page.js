function checkData() {
    var Moyenne = parseFloat(document.getElementById('Moyenne').value);
    var Poids = parseFloat(document.getElementById('Poids').value);
    var image = document.getElementById('background-image');
    var yesno = false;
    var yesno2 = false;
    
    var msg1 = document.getElementById('msgErrorTitu');
    var msg2 = document.getElementById('msgErrorCarte');
    var result = document.getElementById('Result');
    var result2 = document.getElementById('Result2');
    var titre = document.getElementById('titre');
    var video = document.getElementById('background-video');

    video.pause();
    video.currentTime = 0;
    titre.innerHTML = 'Grade Calculator'
    titre.style.color = 'Black';
    
    if (isNaN(Moyenne)) {
        msg1.innerHTML = 'This field is required.';
        image.src = "../image/man-holding-calculator.jpg";
        image.style.zIndex = "-1";
        result.innerHTML='';
        result2.innerHTML='';
    } else if (Moyenne < 0 || Moyenne > 100.0) {
        msg1.innerHTML = 'Error. The average must be between 0 and 100.';
        image.src = "../image/man-holding-calculator.jpg";
        result.innerHTML = '';
        result2.innerHTML = '';
        titre.style.color = 'Black';
        image.style.zIndex = "-1";
        result.innerHTML='';
        result2.innerHTML='';
    } else {
        msg1.innerHTML = '';
        yesno = true;
    }
    
    if (isNaN(Poids)) {
        msg2.innerHTML = 'This field is required.';
        image.src = "../image/man-holding-calculator.jpg";
        image.style.zIndex = "-1";
        result.innerHTML='';
        result2.innerHTML='';
    } else if (Poids < 0 || Poids > 100.0) {
        msg2.innerHTML = 'Error. The weight must be between 0 and 100.';
        image.src = "../image/man-holding-calculator.jpg";
        image.style.zIndex = "-1";
        result.innerHTML='';
        result2.innerHTML='';
    } else {
        msg2.innerHTML = '';
        yesno2 = true;
    }

    if (yesno === false || yesno2 === false) {
        return;
    }

    var funny = Poids;
    var poids_restant = (100 - Poids) / 100;
    Poids = Poids / 100;
    var total = ((60 - (Moyenne * Poids)) / poids_restant);
    var maxtotal = ((Moyenne * Poids) + (100 - (Poids * 100)));


    if (isNaN(total)){
        result.innerHTML = '';
        result2.innerHTML = '';
        image.src = "../image/man-holding-calculator.jpg";
        image.style.zIndex = "-1";
    }
    else if (maxtotal < 60){
        result.style.color = 'Red';
        result.innerHTML = 'You failed your class. Please contact your teacher or supervisor.';
        result2.style.color = 'Red';
        result2.innerHTML = "Maximum possible average: " + maxtotal.toFixed(2);
        titre.style.color = 'Red';
        image.src = "../image/sad.gif";
        image.style.zIndex = "-1";
    }
    else if (total < 0) {
        result.style.color = 'Green';
        result.innerHTML = "Congrats! You don't need to worry about your grades anymore!";
        result2.style.color = 'Green';
        result2.innerHTML = "Maximum possible average: " + maxtotal.toFixed(2);
        titre.style.color = 'Green';

        video.src = "../image/Running Senator Armstrong Green Screen - Revengeance Status Template Green Screen.mp4";
        video.style.display = 'block';
        video.style.zIndex = '-2'
        image.style.zIndex = "-3";
        setTimeout(function() {
            video.play();
        }, 5000);
    }
    
    else if ((Moyenne===69)&&(funny===69)){
        result.style.color = 'Pink';
        result.innerHTML = "6969696 6969696969: " + total.toFixed(2);
        result2.style.color = 'Pink';
        result2.innerHTML = "6969696 69696969 69696969: " + maxtotal.toFixed(2);
        titre.style.color = 'Pink';
        titre.innerHTML = '69696969696 69 6969696'
        image.src = "../image/happy.gif";
        image.style.zIndex = "-1";
    }
    
    else {
        result.style.color = 'Green';
        result.innerHTML = "Required average: " + total.toFixed(2);
        result2.style.color = 'Green';
        result2.innerHTML = "Maximum possible average: " + maxtotal.toFixed(2);
        titre.style.color = 'Green';
        image.src = "../image/hapi.gif";
        image.style.zIndex = "-1";
    }
}
